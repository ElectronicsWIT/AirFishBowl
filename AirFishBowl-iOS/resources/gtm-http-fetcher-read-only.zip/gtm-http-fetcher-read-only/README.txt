Information on using the Google Toolbox for Mac HTTP Fetcher project 
is available at

http://code.google.com/p/gtm-http-fetcher/
